"""
Example file for using the series_scorer class
"""
import series_scorer as ss
import numpy as np

comp = ss.Scorer(input_data=np.random.rand(20, 100))
comp.SSA(
    rank=2,
    window_size=3,
    svd_algo="randomised",
    method="reconstruct",
    num_jobs=1,
    verbosity=0,
)
distance_matrix = comp.cross_score(difference_measure="twed", nu=0.5, lambda_=0.5)
print(distance_matrix[0])
##
