"""
Check whether the correct methods are called.
"""
import pytest
from series_scorer.multi_compare import Scorer
import numpy as np

np.random.seed(42)


@pytest.mark.parametrize(
    "num_jobs,call_single,call_multi",
    [
        (1, True, False),
        (2, False, True),
        (-1, False, True),
    ],
)
def test_parallel_access(mocker, num_jobs, call_single, call_multi):
    single_mock = mocker.patch("series_scorer.multi_compare.Scorer.ssa_single")
    multi_mock = mocker.patch("series_scorer.multi_compare.Scorer.ssa_multi")
    x = Scorer(np.random.rand(12, 12))
    x.SSA(2, num_jobs=num_jobs)
    assert (single_mock.call_count > 0) == call_single
    assert (multi_mock.call_count > 0) == call_multi


def test_stop_early_access():
    x = Scorer(np.random.rand(12, 12))
    with pytest.raises(AttributeError):
        x.cross_score(difference_measure="euclidean")
