from series_scorer import Scorer
import numpy as np
import logging

LOGGER = logging.getLogger(__name__)


def test_rank_high_warning(caplog):
    x = np.random.rand(100, 100)
    s = Scorer(x)
    with caplog.at_level(logging.WARNING):
        s.SSA(rank=400)
    assert "Rank was set higher" in caplog.text


def test_log_level_info_printed(caplog):
    x = np.random.rand(25, 25)
    s = Scorer(x)
    with caplog.at_level(logging.INFO, logger=__name__):
        s.SSA(rank=20, verbosity=1, num_jobs=1)
    assert "single" in caplog.text


def test_log_only_relevant_printed(caplog):
    x = np.random.rand(25, 25)
    s = Scorer(x)
    with caplog.at_level(logging.INFO, logger=__name__):
        s.SSA(rank=20, verbosity=1, num_jobs=1)
    assert "multi job" not in caplog.text


def test_log_level_higher_not_printed(caplog):
    x = np.random.rand(25, 25)
    s = Scorer(x)
    with caplog.at_level(logging.INFO, logger=__name__):
        s.SSA(rank=20, verbosity=1, num_jobs=1)
    assert "Score for indices" not in caplog.text
