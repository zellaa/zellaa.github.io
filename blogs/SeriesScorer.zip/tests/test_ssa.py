import pytest
from series_scorer.ssa import SSA

from series_scorer.helper_functions import (
    get_elementary_matrix,
    hankelise,
    generate_indices,
    randomised_svd,
)
import numpy as np

np.random.seed(42)


@pytest.mark.parametrize(
    "series,rank,window_size",
    [
        (np.arange(25), 4, 5),
        (np.random.rand(30), 3, 10),
        (np.random.rand(12), 2, 4),
    ],
)
def test_hankelisation(series, rank, window_size):
    K = series.shape[0] - window_size + 1
    mat = hankelise(series, window_size, K)
    assert np.all(mat[1:, :-1] == mat[:-1, 1:])


@pytest.mark.parametrize(
    "series,rank,window_size",
    [
        (np.arange(25), 500, 5),
        (np.random.rand(30), 399, 10),
        (np.random.rand(12), 200, 4),
    ],
)
def test_rank_reset(series, rank, window_size):
    x = SSA(series=series, rank=rank, window_size=window_size)
    set_rank = rank
    x.reconstruct(method="reconstruct")
    new_rank = x.rank
    initial_rank = x.full_initial_rank
    assert new_rank == initial_rank
    assert set_rank > new_rank


@pytest.mark.parametrize(
    "series,rank,window_size",
    [
        (np.arange(25), 500, 5),
        (np.random.rand(30), 399, 10),
        (np.random.rand(12), 200, 4),
        (np.random.rand(65), 200, 20),
    ],
)
def test_elementary_matrix_creation(series, rank, window_size):
    x = SSA(series=series, rank=rank, window_size=window_size)
    traj_mat = x.trajectory_matrix
    u, s, v = np.linalg.svd(traj_mat)
    rank_of_traj_mat = np.linalg.matrix_rank(traj_mat)
    for i, sing_val in enumerate(s[:rank_of_traj_mat]):
        sing_mat = get_elementary_matrix(sing_val, u, v, i)
        _, s, _ = np.linalg.svd(sing_mat)
        rank_of_generated_matrix = np.sum(s > 1e-10)
        assert rank_of_generated_matrix == 1


@pytest.mark.parametrize(
    "series,rank,window_size,expected",
    [
        (
            np.array([1, 1, 3, 5, 8, 13, 21]),
            2,
            3,
            np.array([0.83, 1.32, 2.86, 5.00, 8.02, 12.98, 21.01]),
        ),
        (
            np.array([3, 1, 4, 1, 5, 9, 2, 6, 5]),
            2,
            4,
            np.array([2.55, 1.29, 4.43, 2.69, 4.00, 6.33, 2.91, 7.67, 5.40]),
        ),
    ],
)
def test_series_reconstruction_from_svd(series, rank, window_size, expected):
    x = SSA(series=series, rank=rank, window_size=window_size)
    reconstructed = x.reconstruct(method="reconstruct")
    assert np.allclose(reconstructed, expected, atol=1e-1)


@pytest.mark.parametrize(
    "n",
    [
        3,
        20,
        100,
    ],
)
def test_generating_indices(n):
    tuple_type = np.dtype(
        [
            ("i", np.int64),
            ("j", np.int64),
        ]
    )
    indices = np.array(generate_indices(n)).astype(np.ndarray)
    lower_triangular = np.tril_indices(n, -1)
    lower_triangular = np.array(
        list(zip(lower_triangular[0], lower_triangular[1])), dtype=tuple_type
    )
    assert np.all(indices == lower_triangular)


@pytest.mark.parametrize(
    "input_matrix,rank",
    [
        (np.random.rand(200, 30), 10),
        (np.random.rand(150, 200), 50),
        (np.random.rand(500, 600), 20),
    ],
)
def test_randomised_svd(input_matrix, rank):
    Ru, Rs, Rv = randomised_svd(input_matrix, rank)
    random_trunc_svd = np.dot(Ru, np.dot(np.diag(Rs), Rv))
    u, s, v = np.linalg.svd(input_matrix)
    u = u[:, :rank]
    s = s[:rank]
    v = v[:rank, :]
    trun_svd = np.dot(u, np.dot(np.diag(s), v))
    scale_factor = np.linalg.norm(input_matrix - trun_svd, ord="fro") / np.linalg.norm(
        input_matrix - random_trunc_svd, ord="fro"
    )
    assert (
        scale_factor <= 1
    )  # Testing Theorem 15.1 from C6.1 NLA Lecture Notes, Nakatsukasa (2023)
