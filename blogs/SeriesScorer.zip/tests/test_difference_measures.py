import pytest
from series_scorer.multi_compare import Scorer
import numpy as np

np.random.seed(42)


@pytest.mark.parametrize(
    "input,distance_metric,result",
    [
        (np.random.rand(2, 3), "euclidean", 16),
        (np.random.rand(2, 3), 0.5, 8),
        (np.random.rand(2, 3), 2, 64),
    ],
)
def test_distance_metric_scaling(input, distance_metric, result):
    zerodist = Scorer(input_data=input)
    zerodist.SSA(2, num_jobs=2, verbosity=2)
    zerodist.ssa_reconstruction = np.array([[9, 1, 1], [5, -3, 1]])
    zerodist.cross_score(
        difference_measure="twed",
        distance_metric=distance_metric,
        nu=0.5,
        lambda_=0.5,
    )
    assert zerodist.distance_matrix[1, 0] == result


@pytest.mark.parametrize(
    "difference_measure,series,result,params",
    [
        ("euclidean", np.array([[1, 1, 1], [0, 0, 0]]), np.sqrt(3), {"nu": 3}),
        (
            "twed",
            np.array([[5, -3, 1], [9, 1, 1]]),
            16,
            {"nu": 0.5, "lambda_": 0.5},
        ),
        (
            "dtw",
            np.array([[1, 0, 3], [1, 5, 1]]),
            9,
            {"window": 2, "distance_metric": 2},
        ),
    ],
)
def test_correct_measure_results(difference_measure, series, result, params):
    x = Scorer(input_data=series)
    x.SSA(2)
    x.ssa_reconstruction = series
    x.cross_score(difference_measure=difference_measure, **params)
    assert np.isclose(x.distance_matrix[1, 0], result)


@pytest.mark.parametrize(
    "input,difference_measure,params",
    [
        (np.random.rand(15, 15), "euclidean", {"nu": 2}),
        (np.random.rand(12, 12), "twed", {"nu": 0.5, "lambda_": 0.5}),
        (np.random.rand(12, 12), "dtw", {"window": 2}),
    ],
)
def test_symmetric_matrices(input, difference_measure, params):
    symm = Scorer(input_data=input)
    symm.SSA(rank=4, num_jobs=2, verbosity=2)
    symm.cross_score(difference_measure=difference_measure, **params)
    np.testing.assert_array_equal(symm.distance_matrix, symm.distance_matrix.T)
