"""
Tests whether input data is correctly validated.
"""
import pytest
from series_scorer.multi_compare import Scorer
import numpy as np

np.random.seed(42)


@pytest.mark.parametrize(
    "input_data",
    (
        (13),
        ("hello"),
        (np.array([])),
        (np.array([1, 2, np.inf, 4, 5, 6, 7, 8, 9, 10])),
        (np.zeros((3, 3, 3))),
    ),
)
def test_input_data_validation(input_data):
    with pytest.raises(ValueError):
        Scorer(input_data=input_data)


@pytest.mark.parametrize(
    "inp,win",
    [
        (np.random.rand(12, 12), -3),
        (np.random.rand(12, 12), "hello"),
        (np.random.rand(12, 12), 500),
    ],
)
def test_window_size_validation_errors(inp, win):
    x = Scorer(inp)
    with pytest.raises(ValueError):
        x.SSA(2, window_size=win)


@pytest.mark.parametrize(
    "inp,win",
    [
        (np.random.rand(12, 12), None),
    ],
)
def test_window_size_validation_errors_not_set(inp, win):
    x = Scorer(inp)
    x.SSA(rank=2)
    assert x.window_size == (12 + 1) // 2


@pytest.mark.parametrize(
    "inp,rank",
    [
        (np.random.rand(12, 12), -3),
        (np.random.rand(12, 12), "hello"),
        (np.random.rand(12, 12), 0.5),
        (np.random.rand(12, 12), 6.5),
    ],
)
def test_rank_validation(inp, rank):
    x = Scorer(inp)
    with pytest.raises(ValueError):
        x.SSA(rank=rank)


@pytest.mark.parametrize(
    "inp,method",
    [
        (np.random.rand(12, 12), "hello"),
        (np.random.rand(12, 12), 0.5),
        (np.random.rand(12, 12), "r"),
    ],
)
def test_method_validation(inp, method):
    x = Scorer(inp)
    with pytest.raises(ValueError):
        x.SSA(rank=2, method=method)


@pytest.mark.parametrize(
    "inp,numjobs",
    [
        (np.random.rand(12, 12), "-1"),
        (np.random.rand(12, 12), 4.5),
        (np.random.rand(12, 12), -3),
        (np.random.rand(12, 12), 0),
    ],
)
def test_numjobs_validation_error(inp, numjobs):
    x = Scorer(inp)
    with pytest.raises(ValueError):
        x.SSA(rank=2, num_jobs=numjobs)


@pytest.mark.parametrize(
    "inp,numjobs,expected",
    [
        (np.random.rand(12, 12), -1, -1),
    ],
)
def test_numjobs_validation(inp, numjobs, expected):
    x = Scorer(inp)
    x.SSA(rank=2, num_jobs=numjobs)
    assert x.num_jobs == expected


@pytest.mark.parametrize(
    "inp,verbosity,expected",
    [
        (np.random.rand(12, 12), 0, 30),
        (np.random.rand(12, 12), 1, 20),
        (np.random.rand(12, 12), 2, 10),
    ],
)
def test_verbosity_validation_conversions(inp, verbosity, expected):
    x = Scorer(inp)
    x.SSA(rank=2, verbosity=verbosity)
    assert x.verbosity == expected


@pytest.mark.parametrize(
    "inp,verbosity",
    [
        (np.random.rand(12, 12), -1),
        (np.random.rand(12, 12), 30),
        (np.random.rand(12, 12), 0.5),
    ],
)
def test_verbosity_validation_errors(inp, verbosity):
    x = Scorer(inp)
    with pytest.raises(ValueError):
        x.SSA(rank=2, verbosity=verbosity)


@pytest.mark.parametrize(
    "input_data,timesteps",
    [
        (np.random.rand(12, 12), np.random.rand(3, 3)),
        (np.random.rand(3, 3), np.array([[1, 2, 3], [np.inf, 1, 2], [3, 4, 5]])),
        (np.random.rand(12, 12), 0.5),
        (np.random.rand(3, 12), np.random.rand(12, 3)),
    ],
)
def test_timestep_validation(input_data, timesteps):
    with pytest.raises(ValueError):
        Scorer(input_data=input_data, timesteps=timesteps)


@pytest.mark.parametrize(
    "input_data,timesteps",
    [
        (np.random.rand(12, 12), None),
    ],
)
def test_input_data_validation_autoset(input_data, timesteps):
    m = Scorer(input_data, timesteps=timesteps)
    m.SSA(rank=2, num_jobs=1)
    m.cross_score(difference_measure="euclidean")
    assert m.timesteps.shape == input_data.shape
    assert m.timesteps[-1].all() == m.timesteps[0].all()


@pytest.mark.parametrize(
    "input_data,difference_measure",
    [
        (np.random.rand(12, 12), "timewarp"),
        (np.random.rand(12, 12), "euc"),
        (np.random.rand(12, 12), 2),
    ],
)
def test_difference_measure_validation(input_data, difference_measure):
    m = Scorer(input_data)
    m.SSA(rank=2, num_jobs=1)
    with pytest.raises(ValueError):
        m.cross_score(difference_measure=difference_measure)


@pytest.mark.parametrize(
    "diff_method,params_dist",
    [
        ("twed", {"nu": -1, "lambda_": 1}),
        ("twed", {"nu": 1, "lambda_": -1}),
        ("dtw", {"window": -1}),
        ("dtw", {"distance_metric": -1}),
        ("twed", {"distance_metric": 0}),
        ("twed", {"distance_metric": None}),
        ("twed", {"distance_metric": np.inf}),
    ],
)
def test_distance_params_validation(diff_method, params_dist):
    m = Scorer(np.random.rand(12, 12))
    m.SSA(rank=2, num_jobs=2)
    with pytest.raises(ValueError):
        m.cross_score(difference_measure=diff_method, **params_dist)


@pytest.mark.parametrize(
    "metric",
    [
        ("hello"),
        (0),
        (-1),
    ],
)
def test_distance_metric_validation(metric):
    s = Scorer(np.random.rand(12, 12))
    s.SSA(rank=2)
    with pytest.raises(ValueError):
        s.cross_score(difference_measure="euclidean", distance_metric=metric)


@pytest.mark.parametrize(
    "algo,method",
    [
        ("hello", "reconstruct"),
        ("randomised", "full"),
    ],
)
def test_svd_algo_validation_errors(algo, method):
    s = Scorer(np.random.rand(12, 12))
    with pytest.raises(ValueError):
        s.SSA(rank=2, svd_algo=algo, method=method)


@pytest.mark.parametrize(
    "algo,method",
    [
        ("randomised", "reconstruct"),
    ],
)
def test_svd_algo_validation_pass(algo, method):
    s = Scorer(np.random.rand(2, 1000))
    s.SSA(rank=20, svd_algo=algo, method=method)
