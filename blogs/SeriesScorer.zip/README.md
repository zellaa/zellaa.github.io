### Installation:
This project was built with [Poetry 1.51](https://python-poetry.org/docs/basic-usage/), using **Python 3.10**.
A basic setup is to
1. Install Poetry [online](https://python-poetry.org/docs/#installation), or use either of the sources provided in
`PROJECT_DIR/poetry_sources/` (see [here](https://github.com/python-poetry/poetry/releases) for the GitHub source).
2. `cd` into the project directory `PROJECT_DIR/`
3. Run `poetry install` to install the dependencies which should be placed in a virtual environment located 
in the `PROJECT_DIR/.venv/` directory. **If this is not desired, delete `poetry.toml` and run the same command**, and 
the virtual environment will be created in cache [directory](https://python-poetry.org/docs/configuration/#cache-directory),
under `~/.cache/pypoetry/virtualenvs` on Linux.
4. Run `poetry shell` within `PROJECT_DIR/` to activate the virtual environment.
5. Proceed to use the virtual environment as you would normally, for example by running `python example_usage.py` to run the provided example file. Exit the virtual environment by running `exit`.

Alternatively, note there are built packages for `series_scorer` in the `PROJECT_DIR/dist/` directory, which may be installed as you wish.
### Usage
* See `example_usage.py` for a minimal example, or view the docstring for `SeriesScorer.Scorer()`
* `pytest` is used for testing; `results_test.txt` contains the results of running `pytest tests/` on the project.
