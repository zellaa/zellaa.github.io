"""
This file defines various difference measurements for time series.
Currently implemented are:
    - Euclidean distance
    - Time Warp Edit Distance
    - Dynamic Time Warping
Each of these classes take in two time series, and output either a single value or a distance matrix.
By default, the distance matrix is not returned and must be explicitly requested by an end user.

!!
All classes assume correct input has been passed in on the time series data (these checks are made earlier in the
code), but do perform checks on parameters passed in.
!!
"""
from __future__ import annotations
import numpy as np
from numpy import ndarray
from numbers import Number
import logging

logger = logging.getLogger(__name__)


def difference_measurement_calculate(
    value1: float | ndarray, value2: float | ndarray, distance_metric: str | int
):
    """
    Compute the difference measurement for two values, scaled by an exponent.
    """
    if distance_metric == "euclidean":
        exponent = 1.0
    else:
        exponent = distance_metric

    return np.abs(value1 - value2) ** exponent


class DifferenceMeasure:
    """
    Generic superclass for distance measures.
    """

    def __init__(
        self,
        series1: np.ndarray,
        series2: np.ndarray,
        timestep1: np.ndarray = None,
        timestep2: np.ndarray = None,
        distance_metric: str = "euclidean",
    ):
        """
        Initialize the distance measure class
        """
        self.series1 = series1
        self.series2 = series2
        self.timestep1 = timestep1
        self.timestep2 = timestep2
        self.distance_metric = distance_metric

    @property
    def distance_metric(self):
        """
        Define the validation for the distance metric.
        :return:
        """
        return self.__distance_metric

    @distance_metric.setter
    def distance_metric(self, value: str | int | float):
        if value == "euclidean":
            self.__distance_metric = value
        elif value == np.inf:
            raise ValueError("Distance metric must be finite.")
        elif issubclass(type(value), Number) and value > 0:
            self.__distance_metric = value
        else:
            raise ValueError("Distance metric must be one of 'euclidean', or a number.")

    def score(self, **kwargs):
        """
        Compute the distance between two series.
        This method is a placeholder to be overridden by subclasses.
        """
        pass


class Euclidean(DifferenceMeasure):
    """
    Compute the Euclidean distance between two series.

    Has one method:
        - score: Compute the Euclidean distance between two series.
    """

    def __init__(self, **kwargs):
        super().__init__(
            series1=kwargs.pop("series1"),
            series2=kwargs.pop("series2"),
            timestep1=kwargs.pop("timestep1"),
            timestep2=kwargs.pop("timestep2"),
        )
        if kwargs.get("distance_metric") not in ["euclidean", 2]:
            logger.warning(
                "Euclidean distance measure does not use distance metric parameter."
            )

    def score(self):
        """
        Computes the Euclidean distance between two series.
        """
        return np.linalg.norm(self.series1 - self.series2)


class Elastic(DifferenceMeasure):
    """
    Class for elastic distance measures.
    These classes use distance matrices and dynamic programming to compute the distance between two series.
    """

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        # Initialize the distance matrix:
        self.elastic_matrix = np.full(
            (len(self.series1) + 1, len(self.series2) + 1), np.inf
        )
        self.elastic_matrix[0, 0] = 0

        # Prepend a zero to the series and timesteps:
        self.series1 = np.insert(self.series1, 0, 0)
        self.series2 = np.insert(self.series2, 0, 0)
        self.timestep1 = np.insert(self.timestep1, 0, 0)
        self.timestep2 = np.insert(self.timestep2, 0, 0)


class TimeWarp(Elastic):
    """
    Compute the Time Warp Edit Distance between two series.
    Parameters this class uses are:
        - Lambda: The cost of a deletion in either series.
        - Nu: The stiffness parameter associated with TWED, penalising time-warping.

    Has one method:
        - score: Returns either the TWED distance between the two series, or optionally the distance matrix too.
    """

    def __init__(
        self,
        **kwargs,
    ):
        super().__init__(
            series1=kwargs.pop("series1"),
            series2=kwargs.pop("series2"),
            timestep1=kwargs.pop("timestep1"),
            timestep2=kwargs.pop("timestep2"),
            distance_metric=kwargs.pop("distance_metric", "euclidean"),
        )

        self.lambda_ = kwargs.get("lambda_", None)
        self.nu = kwargs.get("nu", None)

    @property
    def lambda_(self):
        """
        Return the lambda parameter.
        """
        return self.__lambda_

    @lambda_.setter
    def lambda_(self, value: int | float):
        if value == np.inf:
            raise ValueError("Lambda must be finite.")
        elif issubclass(type(value), Number) and value >= 0:
            self.__lambda_ = value
        else:
            raise ValueError("Lambda must be a number greater than or equal to zero.")

    @property
    def nu(self):
        """
        Return the nu parameter.
        """
        return self.__nu

    @nu.setter
    def nu(self, value: int | float):
        if value == np.inf:
            raise ValueError("Nu must be finite.")
        elif issubclass(type(value), Number) and value >= 0:
            self.__nu = value
        else:
            raise ValueError("Nu must be a number greater than or equal to zero.")

    def score(self, return_matrix: bool = False):
        """
        Compute the Time Warp Edit Distance between the two series given,
        by iteratively computing the distance matrix.
        :return:
        """
        for i, _ in enumerate(self.series1[:-1]):
            for j, _ in enumerate(self.series2[:-1]):
                match_cost = (
                    self.elastic_matrix[i, j]
                    + difference_measurement_calculate(
                        self.series1[i + 1], self.series2[j + 1], self.distance_metric
                    )
                    + difference_measurement_calculate(
                        self.series1[i], self.series2[j], self.distance_metric
                    )
                    + self.nu
                    * (
                        np.abs(self.timestep1[i] - self.timestep2[j])
                        + np.abs(self.timestep1[i + 1] - self.timestep2[j + 1])
                    )
                )

                deletion_in_1_cost = (
                    self.elastic_matrix[i, j + 1]
                    + difference_measurement_calculate(
                        self.series1[i], self.series1[i + 1], self.distance_metric
                    )
                    + self.nu * (self.timestep1[i + 1] - self.timestep1[i])
                    + self.lambda_
                )

                deletion_in_2_cost = (
                    self.elastic_matrix[i + 1, j]
                    + difference_measurement_calculate(
                        self.series2[j], self.series2[j + 1], self.distance_metric
                    )
                    + self.nu * (self.timestep2[j + 1] - self.timestep2[j])
                    + self.lambda_
                )

                self.elastic_matrix[i + 1, j + 1] = min(
                    match_cost, deletion_in_1_cost, deletion_in_2_cost
                )

        if return_matrix:
            return self.elastic_matrix[-1, -1], self.elastic_matrix
        else:
            return self.elastic_matrix[-1, -1]


class DTW(Elastic):
    """
    Compute the Dynamic Time Warping distance between two series, as defined in
    https://doi.org/10.1016/j.knosys.2014.04.035.
    The only parameter this class uses is:
        - Window: The "windowing" parameter in DTW, which constrains time-warping.

    Has one method:
        - score: Returns either the DTW distance between the two series, or optionally the distance matrix too.
    """

    def __init__(
        self,
        **kwargs,
    ):
        super().__init__(
            series1=kwargs.pop("series1"),
            series2=kwargs.pop("series2"),
            timestep1=kwargs.pop("timestep1"),
            timestep2=kwargs.pop("timestep2"),
            distance_metric=kwargs.pop("distance_metric", "euclidean"),
        )
        self.window = kwargs.get("window", None)

    @property
    def window(self):
        """
        Return the window parameter.
        """
        return self.__window

    @window.setter
    def window(self, value: int | float):
        if value == np.inf:
            raise ValueError("Window must be finite.")
        elif issubclass(type(value), Number) and value >= 0:
            self.__window = value
        else:
            raise ValueError("Window must be a number greater than or equal to zero.")

    def score(self, return_matrix: bool = False):
        """
        Score DTW using formulation from equation (5) in
        https://doi.org/10.1016/j.knosys.2014.04.035.
        :param return_matrix:
        :return:
        """
        for i, _ in enumerate(self.series1[:-1]):
            min_j_index = max(0, i - self.window + 1)
            max_j_index = min(len(self.series2) - 1, i + self.window)
            for j in range(min_j_index, max_j_index):
                cost = difference_measurement_calculate(
                    self.series1[i + 1], self.series2[j + 1], self.distance_metric
                )

                match_cost = self.elastic_matrix[i, j] + cost
                deletion_1_cost = self.elastic_matrix[i, j + 1] + cost
                deletion_2_cost = self.elastic_matrix[i + 1, j] + cost

                self.elastic_matrix[i + 1, j + 1] = min(
                    match_cost, deletion_1_cost, deletion_2_cost
                )

        if return_matrix:
            return self.elastic_matrix[-1, -1], self.elastic_matrix
        else:
            return self.elastic_matrix[-1, -1]
