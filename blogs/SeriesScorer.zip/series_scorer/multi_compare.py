"""
A class to generate both SSA-smoothed series, and potentially distance matrices given an input of various time series
data of size n x T, where n is the number of time series and T is the length of the time series.

Also accepts as optional input a list of timesteps for each time series, of the same dimensions.
If left empty, the timesteps are assumed to be equidistant.
"""
from __future__ import annotations
from pathos.multiprocessing import ProcessPool as Pool
import numpy as np
from numbers import Number
from functools import partial
import logging

from series_scorer.ssa import SSA
from series_scorer.differences import TimeWarp, DTW, Euclidean
from series_scorer.helper_functions import generate_indices

logger = logging.getLogger(__name__)
logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s (%(filename)s:%(lineno)d)",
)


class Scorer:
    """
    This class takes in an array of time series data of size n x T, where n is the number of time series and T is the
    length of the time series, as well as optional timestep data of the same format.
    SSA can then be applied to each time series, and the difference between each time series may be computed as well.

    The following methods are to be called by user:
        - SSA()
        - cross_score()

    Example usage:
        > comp = Scorer(input_data=np.random.rand(12, 12))
        > comp.SSA(rank=2, window_size=3,method="reconstruct",svd_algo="randomised, num_jobs=1, verbosity=2)
        > comp.cross_score(difference_measure="twed", nu=0.5, lambda_=0.5)
    """

    def __init__(self, input_data: np.ndarray, timesteps: np.ndarray | bool = None):
        """
        Initialize the Scorer object, with a required input_array and optional timesteps.
        """
        self.singular_value_data = None
        self.ssa_components = None
        self.ssa_reconstruction = None
        self.input_data = input_data
        self.num_series = input_data.shape[0]
        self.series_length = input_data.shape[1]
        self.timesteps = timesteps
        self.distance_matrix = np.zeros((self.num_series, self.num_series))
        self.window_size = None

    @property
    def input_data(self):
        """
        Return the input data.
        """
        return self.__input_data

    @input_data.setter
    def input_data(self, value: np.ndarray):
        if not isinstance(value, np.ndarray):
            raise ValueError("Input data must be a numpy array.")
        elif np.isnan(value).any():
            raise ValueError(
                "The time series given have missing values, please check your data."
            )
        elif np.isinf(value).any():
            raise ValueError(
                "The time series given have infinite values, please check your data."
            )
        elif not np.issubdtype(value.dtype, np.number):
            raise ValueError("The time series given are not numpy numerical arrays.")
        elif len(value.shape) != 2:
            raise ValueError(
                "The input data must be a 2D array of size n x T, "
                "where n is the number of time series and T is the length of the time series."
            )
        else:
            self.__input_data = value

    @property
    def timesteps(self):
        """
        Return the timesteps.
        """
        return self.__timesteps

    @timesteps.setter
    def timesteps(self, value: np.ndarray | None):
        if value is None:
            self.__timesteps = np.tile(
                np.arange(self.series_length),
                (self.num_series, 1),
            )
        elif not isinstance(value, np.ndarray):
            raise ValueError("Timesteps must be a numpy array.")
        elif np.isnan(value).any():
            raise ValueError(
                "The timesteps given have missing values, please check your data."
            )
        elif np.isinf(value).any():
            raise ValueError(
                "The timesteps given have infinite values, please check your data."
            )
        elif not np.issubdtype(value.dtype, np.number):
            raise ValueError("The timesteps given are not numpy numerical arrays.")
        elif value.shape != self.input_data.shape:
            raise ValueError(
                "The timesteps must be a 2D array of the same size as the input data."
            )
        else:
            self.__timesteps = value

    @property
    def method(self):
        """
        Return the method.
        """
        return self.__method

    @method.setter
    def method(self, value: str):
        if value not in [
            "reconstruct",
            "singular_values",
            "components",
            "full",
        ]:
            raise ValueError(
                "Method must be one of 'reconstruct', 'singular_values', 'components', 'full'."
            )
        else:
            self.__method = value

    @property
    def num_jobs(self):
        """
        Return the number of jobs.
        """
        return self.__num_jobs

    @num_jobs.setter
    def num_jobs(self, value: int):
        if not isinstance(value, int):
            raise ValueError("Number of jobs must be an integer.")
        elif value == -1 or value >= 1:
            if value != 1:
                logger.warning(
                    "Using multiple cores may cause significant overhead, and is not recommended for small datasets."
                )
            self.__num_jobs = value
        else:
            raise ValueError("Number of jobs must be >=1, or -1 to use all cores.")

    @property
    def verbosity(self):
        """
        Return the verbosity.
        """
        return (3 - self.__verbosity) * 10

    @verbosity.setter
    def verbosity(self, value: int):
        if value not in [0, 1, 2]:
            raise ValueError("Verbosity must be one of 0, 1, 2.")
        else:
            self.__verbosity = value

    @property
    def rank(self):
        """
        Return the rank.
        """
        return self.__rank

    @rank.setter
    def rank(self, value: int):
        if not isinstance(value, int):
            raise ValueError("Rank must be an integer.")
        elif value < 1:
            raise ValueError("Rank must be >1.")
        else:
            self.__rank = value

    @property
    def window_size(self):
        """
        Return the window size.
        """
        return self.__window_size

    @window_size.setter
    def window_size(self, value: int | None):
        if value is None:
            self.__window_size = (self.series_length + 1) // 2
        else:
            if not isinstance(value, int):
                raise ValueError("Window size must be an integer.")
            elif value < 1:
                raise ValueError("Window size must be >1.")
            elif value > (self.series_length + 1) // 2:
                raise ValueError(
                    "Window size must be <= half the length of the time series."
                )
            else:
                self.__window_size = value

    @property
    def difference_measure(self):
        """
        Return the difference measure used.
        """
        return self.__difference_measure

    @difference_measure.setter
    def difference_measure(self, measure: str):
        if measure not in ["twed", "euclidean", "dtw"]:
            raise ValueError(
                "Difference measure must be one of 'twed', 'euclidean', or 'dtw'."
            )
        else:
            self.__difference_measure = measure

    @property
    def distance_metric(self):
        """
        Return the difference metric used.
        """
        return self.__distance_metric

    @distance_metric.setter
    def distance_metric(self, metric: str | Number):
        # check distance metric is a number greater than 0:
        if metric == np.inf:
            raise ValueError("Distance metric must be finite.")
        elif issubclass(type(metric), Number) and metric > 0:
            self.__distance_metric = metric
        elif metric == "euclidean":
            self.__distance_metric = metric
        else:
            raise ValueError(
                "Distance metric must be a number greater than or equal to zero, or 'euclidean'."
            )

    @property
    def svd_algo(self):
        """
        Return the SVD algorithm used.
        """
        return self.__svd_algo

    @svd_algo.setter
    def svd_algo(self, algo: str):
        if algo == "randomised":
            if self.method == "reconstruct":
                self.__svd_algo = algo
            else:
                raise ValueError(
                    "Randomised SVD can only be used for when `method=reconstruct`."
                )
        elif algo == "full":
            self.__svd_algo = algo
        else:
            raise ValueError("SVD algorithm must be one of 'randomised' or 'full'.")

    def SSA(
        self,
        rank: int,
        window_size: int = None,
        method: str = "reconstruct",
        svd_algo: str = "full",
        num_jobs: int = 1,
        verbosity: int = 1,
    ):
        """
        Construct SSA on the given series.

        Inputs:
            - rank: The rank of the SSA decomposition, i.e. the number of components to use.
            - window_size: The window size to use for the SSA decomposition. Must be <= the T/2,
            where T is the length of the time series.
            - method: The method to use for the SSA decomposition. Must be one of
                :reconstruct: Reconstruct the time series using the SSA components,
                    accessed via the `ssa_reconstruction` attribute.
                :singular_values: Return the singular values of the SSA decomposition,
                    accessed via the `singular_value_data` attribute.
                :components: Return the SSA components corresponding to rank-1 elementary matrices, accessible via
                    the `ssa_components` attribute.
                :full: Return the full SSA decomposition, which in essence computes all three of the above, and which
                    are then accessible by their respective attributes.
            - svd_algo: The SVD algorithm to use. Must be one of 'full', or 'randomised' (the latter
                using the Rangefinder SVD algorithm from Halko et al. (2011)).
            - verbosity: The level of verbosity to use. Must be either 0,1,2 for no output,
                limited output, or verbose output.
            - num_jobs: The number of jobs to use for the computation. Must be an integer >1, or -1 to use all cores.

        Note that num_jobs should only be modified in the case of very large time series, or for very many series,
        as the overhead of multiprocessing can be significant for smaller datasets compared to the time taken
        to compute the SSA and difference scores.
        """
        self.window_size = window_size
        self.rank = rank
        self.num_jobs = num_jobs
        self.verbosity = verbosity
        self.method = method
        self.svd_algo = svd_algo
        logger.setLevel(self.verbosity)

        if self.num_jobs == 1:
            logger.info("Using single job SSA.")
            self.ssa_single()
        else:
            logger.info("Using multi job SSA.")
            self.ssa_multi()

    def ssa_single(self):
        """
        Computes SSA using a single thread.
        """
        # go over each time series in input_data, and compute its SSA, storing results in a dict
        full_data = {
            index: SSA(
                series=time_series, window_size=self.window_size, rank=self.rank
            ).reconstruct(method=self.method, svd_algo=self.svd_algo)
            for index, time_series in enumerate(self.input_data)
        }
        self.parse_full_data(full_data)

    def ssa_multi(self):
        """
        Computes SSA using multiple num_jobs.
        """
        with Pool(processes=self.num_jobs) as pool:
            full_data = dict(
                pool.map(self.single_series_construct, list(range(self.num_series)))
            )
        self.parse_full_data(full_data)

    def parse_full_data(self, full_data: dict | list):
        """
        Given the full data, sets the appropriate attributes of the Scorer object.
        """
        logger.info("Finished computing SSA for all series.")
        if self.method == "full":
            self.ssa_reconstruction = {
                index: full_data[index]["reconstructed_series"]
                for index in full_data.keys()
            }
            self.singular_value_data = {
                index: full_data[index]["singular_values"] for index in full_data.keys()
            }
            self.ssa_components = {
                index: full_data[index]["components"] for index in full_data.keys()
            }
        elif self.method == "reconstruct":
            self.ssa_reconstruction = {index: full_data[index] for index in full_data}
        elif self.method == "singular_values":
            self.singular_value_data = {index: full_data[index] for index in full_data}
        elif self.method == "components":
            self.ssa_components = {index: full_data[index] for index in full_data}

    def single_series_construct(self, series_index: int):
        """
        Construct the SSA for a single series.
        """
        logger.debug(f"Constructing series {series_index}...")
        return (
            series_index,
            SSA(
                series=self.input_data[series_index],
                window_size=self.window_size,
                rank=self.rank,
            ).reconstruct(self.method, self.svd_algo),
        )

    def cross_score(self, difference_measure: str = "euclidean", **kwargs):
        """
        Compute the cross score of the series using TWED. The attribute `distance_matrix` is then available
        which is the symmetric matrix of cross scores.

        Arguments:
            - difference_measure: The difference measurement to use. Must be one of
                :euclidean: Euclidean distance (assumed by default).
                :twed: TWED distance.
                :dtw: DTW distance.
            - kwargs: Additional arguments to pass to the difference measurement. These depend on what difference
                measurement is used.
                :euclidean: No additional arguments.
                :twed:
                    - lambda_: The lambda parameter for TWED.
                    - nu: The nu parameter for TWED.
                :dtw:
                    - window_size: The window size for DTW.
        """
        logger.info("Computing cross score...")
        if self.ssa_reconstruction is None:
            raise AttributeError(
                "SSA must be computed before cross score can be calculated."
            )
        else:
            self.difference_measure = difference_measure
            self.distance_metric = kwargs.get("distance_metric", "euclidean")
            indices = generate_indices(int(self.input_data.shape[0]))
            logger.info("Computing cross scores...")
            if self.num_jobs == 1:
                for tuple_of_indices in indices:
                    i, j, value = self.multi_score(tuple_of_indices, **kwargs)
                    self.distance_matrix[
                        tuple_of_indices[0], tuple_of_indices[1]
                    ] = value
                    logger.debug(
                        f"Score for indices {tuple_of_indices[0]},{tuple_of_indices[1]}: {value}"
                    )
            else:
                with Pool(processes=self.num_jobs) as score_pool:
                    for i, j, value in score_pool.imap(
                        partial(self.multi_score, **kwargs), indices
                    ):
                        logger.debug(f"Score for indices {i},{j}: {value}")
                        self.distance_matrix[i, j] = value
            self.distance_matrix = self.distance_matrix + self.distance_matrix.T
            return self.distance_matrix

    def multi_score(self, index_list: int, **kwargs):
        """
        For every pair of series, compute the score between them.
        """
        i, j = index_list[0], index_list[1]
        updated_kwargs = {
            "series1": self.ssa_reconstruction[i],
            "series2": self.ssa_reconstruction[j],
            "timestep1": self.timesteps[i],
            "timestep2": self.timesteps[j],
            **kwargs,
        }

        if self.difference_measure == "euclidean":
            score = Euclidean(**updated_kwargs).score()
        elif self.difference_measure == "twed":
            score = TimeWarp(**updated_kwargs).score()
        elif self.difference_measure == "dtw":
            score = DTW(**updated_kwargs).score()
        else:
            raise ValueError(f"Unknown difference measure: {self.difference_measure}.")
        return i, j, score
