"""
Various static functions used within the Scorer and SSA classes.
These shouldn't need to be called by an end user.
"""
from __future__ import annotations

from numba import jit, from_dtype
import numpy as np


tuple_type = np.dtype(
    [
        ("i", np.int64),
        ("j", np.int64),
    ]
)
numba_tuple_type = from_dtype(tuple_type)


@jit(nopython=True, fastmath=True)
def generate_indices(n: int):
    """
    Generate the indices for the lower triangle of a matrix of size n x n.
    Importantly, ignore the diagonal as these distances are all 0 (as these correspond to the distance
    between a series and itself in the distance matrix).
    """
    list_of_indices = np.zeros(n * (n - 1) // 2, dtype=numba_tuple_type)
    for index in range(n * (n - 1) // 2):
        i = np.int64(np.floor((1 + np.sqrt(1 + 8 * index)) / 2))
        j = index - i * (i - 1) // 2
        list_of_indices[index].i = i
        list_of_indices[index].j = j
    return list_of_indices


@jit(nopython=True, fastmath=True)
def hankelise(series, L: int | float, K: int | float):
    """
    Given a single time series, generate the associated Hankel matrix of size L x K.
    """
    H = np.zeros((L, K))
    for i in range(L):
        H[i, :] = series[i : K + i]
    return H


@jit(nopython=True, fastmath=True)
def get_series_from_truncation(truncated_svd: np.ndarray):
    """
    Reconstruct the series from the truncated SVD, by taking the mean of the off-diagonals.
    We do not construct the full matrix as this is not necessary, but instead just take the mean values and
    add them to a list.
    """
    flipped = np.flipud(truncated_svd)
    min_index, max_index = -truncated_svd.shape[0] + 1, truncated_svd.shape[1]
    reconstructed_series = np.array(
        [np.mean(np.diag(flipped, i)) for i in range(min_index, max_index)]
    )
    return reconstructed_series


@jit(nopython=True, fastmath=True)
def get_elementary_matrix(
    sing_val: int | float, U: np.ndarray, V: np.ndarray, rank_of_sing_vec: int
):
    """
    Given a rank r, compute the r'th elementary matrix. associated with the SVD sum, i.e. sigma_r u_r v_r^T.
    """
    X_r = sing_val * np.outer(U[:, rank_of_sing_vec], V[rank_of_sing_vec, :])
    return X_r


@jit(nopython=True, fastmath=True)
def get_elementary_components(
    components: np.ndarray, S: np.ndarray, U: np.ndarray, V: np.ndarray
):
    """
    Given the singular values and the left and right singular vectors, compute the reconstructed series corresponding
    to each rank-1 elementary matrix.
    The sum of the first n of these components corresponds to a rank-n approximation of the original series.
    """
    for i, singular_value in enumerate(S):
        reconstruction = get_elementary_matrix(singular_value, U, V, i)
        components[i] = get_series_from_truncation(reconstruction)
    return components


def randomised_svd(input_traj_mat: np.ndarray, k: int):
    """
    Compute the SVD of a matrix input_traj_mat using the randomised SVD algorithm, using the
    Rangefinder method (Halko et al. 2011).
    """
    n = input_traj_mat.shape[1]
    Omega = np.random.randn(n, k)
    Q, _ = np.linalg.qr(input_traj_mat @ Omega)
    C = Q.T @ input_traj_mat
    Uhat, S, V = np.linalg.svd(C, full_matrices=False)
    U = Q @ Uhat
    return U, S, V
