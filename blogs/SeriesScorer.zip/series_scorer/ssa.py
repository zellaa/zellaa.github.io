"""
A module to perform Singular Spectrum Analysis (SSA) on a single time series.
By default, this is not run by user, but called via series_scorer.multi_compare.Scorer.

Takes as input a time series and returns the SSA reconstruction of the time series. Requires as input a
time series of shape (T,), a window size not more than half of T, and a rank of reconstruction.
"""
import numpy as np

from series_scorer.helper_functions import (
    hankelise,
    get_series_from_truncation,
    get_elementary_components,
    randomised_svd,
)

import logging

logger = logging.getLogger(__name__)


class SSA:
    """
    A class to generate the Singular Spectrum Analysis (SSA) reconstruction of an array of a single time series.

    The following methods are available:
    - reconstruct(): Reconstruct the time series after an SSA approximation,
        and return output depending on type of reconstruction.
    """

    def __init__(
        self,
        series: np.ndarray,
        rank: int,
        window_size: int,
    ):
        """
        Initialize the SSA object, and construct the hankel trajectory matrix.
        """
        self.svd_algo = None
        self.method = None
        self.time_series_components = None
        self.full_initial_rank = None
        self.singular_values = None
        self.reconstructed_series = None

        self.series = series
        self.window_size = window_size
        self.rank = rank

        self.K = series.shape[0] - self.window_size + 1
        self.reconstruction = np.zeros(self.series.shape)
        logger.debug(f"Computing hankelisation of shape {self.window_size, self.K}...")

        self.trajectory_matrix = hankelise(self.series, self.window_size, self.K)
        if self.rank > min(self.trajectory_matrix.shape):
            logger.warning(
                "Rank was set higher than the shape of the input trajectory matrix. "
                "This will result in a full-rank reconstruction, so we are setting the rank to the minimum dimension."
            )
            self.rank = min(self.trajectory_matrix.shape)

    def reconstruct(self, method: str = "reconstruct", svd_algo: str = "full"):
        """
        Reconstruct the smoothed series.

        Arguments:
            - method: The method of reconstruction. Can be one of:
                :singular_values: Return the singular values of the trajectory matrix.
                :reconstruct: Return the reconstructed series.
                :components: Return the elementary components of the series as a multidimensional array of size
                (full_rank, window_size), with each component in the first dimension (indexing from zero).
                :full: Return the full reconstruction of the series, which computes the three above methods and returns
                a dictionary.
        """
        self.truncated_svd = None
        self.method = method
        self.svd_algo = svd_algo
        if self.svd_algo == "randomised":
            logger.debug(f"Computing randomised SVD truncated at {self.rank}...")
            U, self.singular_values, V = randomised_svd(
                self.trajectory_matrix, self.rank
            )
            self.truncated_svd = U @ np.diag(self.singular_values) @ V
            logger.debug("Computing reconstructed series...")
            self.reconstructed_series = get_series_from_truncation(self.truncated_svd)
            return self.reconstructed_series
        else:
            logger.debug("Computing full SVD...")
            if method == "singular_values":
                self.singular_values = np.linalg.svd(
                    self.trajectory_matrix, compute_uv=False
                )

                self.full_initial_rank = len(self.singular_values)
                if self.rank > self.full_initial_rank:
                    logger.warning(
                        f"Rank was set higher than rank of trajectory matrix, "
                        f"resetting to rank {self.full_initial_rank}."
                    )
                    self.rank = self.full_initial_rank

                return self.singular_values

            U, self.singular_values, V = np.linalg.svd(self.trajectory_matrix)
            self.full_initial_rank = self.singular_values.shape[0]
            if self.rank > self.full_initial_rank:
                logger.warning(
                    f"Rank was set higher than rank of trajectory matrix, resetting to rank {self.full_initial_rank}."
                )
                self.rank = self.full_initial_rank

            if method == "reconstruct":
                # We only want to reconstruct the series, and so discard all other data.
                logger.debug(f"Truncating SVD to rank {self.rank}...")
                self.truncated_svd = (
                    U[:, : self.rank]
                    @ np.diag(self.singular_values[: self.rank])
                    @ V[: self.rank, :]
                )

                logger.debug("Computing reconstructed series...")

                self.reconstructed_series = get_series_from_truncation(
                    self.truncated_svd
                )
                return self.reconstructed_series
            elif method in ["full", "components"]:
                # we now want to reconstruct the series, but also return the singular vectors
                # as well as the series associated with each singular vector.
                logger.debug(f"Truncating SVD to rank {self.rank}...")

                self.time_series_components = np.zeros(
                    (self.full_initial_rank, self.series.shape[0])
                )  # initial_rank x T array, with the ith row being the ith rank component

                logger.debug(
                    "Computing rank one components of the trajectory matrix..."
                )

                self.time_series_components = get_elementary_components(
                    self.time_series_components, self.singular_values, U, V
                )
                if method == "components":
                    return self.time_series_components
                else:
                    # "full" method is only called via user
                    logger.debug("Summing components to reconstruct series...")

                    self.reconstructed_series = np.sum(
                        self.time_series_components[: self.rank], axis=0
                    )

                    return {
                        "reconstructed_series": self.reconstructed_series,
                        "components": self.time_series_components,
                        "singular_values": self.singular_values,
                    }
            else:
                raise ValueError(
                    "Method must be one of 'reconstruct', 'singular_values', 'components' or 'full'."
                )
